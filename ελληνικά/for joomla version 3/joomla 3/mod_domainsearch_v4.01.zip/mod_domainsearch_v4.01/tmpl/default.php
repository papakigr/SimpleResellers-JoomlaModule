<?php


// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.helper');

if(!JComponentHelper::isEnabled('com_papakidomains', true))
{
    JError::raiseError('Domain Search', JText::_('Module requires the Domains Registration component'));
	return;
}
$url= JRoute::_(JURI::base().'index.php?option=com_papakidomains&format=plain');
//print $url;
$html=file_get_contents($url);
print $html;
?>
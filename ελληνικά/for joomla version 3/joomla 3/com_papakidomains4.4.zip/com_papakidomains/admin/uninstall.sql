DROP TABLE IF EXISTS `#__papakidomains_tlds`;

<?php


// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.helper');

if(!JComponentHelper::isEnabled('com_domainregistration', true))
{
    JError::raiseError('Domain Search', JText('Module requires the Domains Registration component'));
	return;
}
$url= JRoute::_(JURI::base().'index.php?option=com_domainregistration&format=plain');
//print $url;
$html=file_get_contents($url);
print $html;
?>
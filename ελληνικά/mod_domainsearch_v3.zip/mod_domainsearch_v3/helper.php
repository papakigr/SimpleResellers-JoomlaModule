<?php


// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modDomainSearchHelper
{
	function getList(&$params)
	{
		global $mainframe;

		$db			=& JFactory::getDBO();
		$user		=& JFactory::getUser();
		$userId		= (int) $user->get('id');

		$db =& JFactory::getDBO();

		$db->setQuery("SELECT * FROM #__domainSearch_conf LIMIT 1");
		$rows = $db->loadObjectList();
		$r = $rows[0];
		return $r;
	}

	function getItemid(&$params)
	{
		global $mainframe;

		$db			=& JFactory::getDBO();
		$user		=& JFactory::getUser();
		$userId		= (int) $user->get('id');

		$db =& JFactory::getDBO();

		$db->setQuery("SELECT id FROM #__menu where link LIKE 'index.php?option=com_domainsearch%' LIMIT 1");
		$Itemid = $db->loadResult();
		return $Itemid;
	}
}
